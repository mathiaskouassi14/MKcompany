# Documentation de la Base de Données Supabase

Ce document décrit la structure de la base de données Supabase pour le projet MK COMPANY, y compris les tables, les politiques de sécurité (RLS), et les fonctions.

## Schéma `public`

### Table `public.users`

Cette table stocke les informations de base sur tous les utilisateurs, qu'ils soient clients ou administrateurs. Elle est synchronisée avec la table `auth.users` via un trigger.

**Colonnes :**
| Colonne | Type | Description |
| :--- | :--- | :--- |
| `id` | `uuid` | Identifiant unique de l'utilisateur (clé primaire, correspond à `auth.users.id`). |
| `email` | `varchar` | Adresse e-mail de l'utilisateur. |
| `first_name` | `varchar` | Prénom de l'utilisateur. |
| `last_name` | `varchar` | Nom de famille de l'utilisateur. |
| `phone` | `varchar` | Numéro de téléphone. |
| `date_of_birth` | `date` | Date de naissance. |
| `plan` | `varchar` | Le plan choisi par le client (ex: `starter`, `professional`). |
| `role` | `varchar` | Rôle de l'utilisateur (`client` ou `admin`). |
| `llc_name` | `varchar` | Nom de la LLC à créer. |
| `formation_state` | `varchar` | État de formation de la LLC. |
| `business_type` | `varchar` | Type d'activité de l'entreprise. |
| `created_at` | `timestamptz` | Date de création de l'utilisateur. |
| `updated_at` | `timestamptz` | Date de la dernière mise à jour. |

**Politiques de Sécurité (RLS) :**
-   **Admins :** Peuvent lire tous les profils utilisateurs.
-   **Clients :** Peuvent lire et mettre à jour uniquement leur propre profil.

---

### Table `public.identity_documents`

Stocke les informations relatives aux documents d'identité soumis par les clients pour vérification.

**Colonnes :**
| Colonne | Type | Description |
| :--- | :--- | :--- |
| `id` | `uuid` | Identifiant unique du document (clé primaire). |
| `user_id` | `uuid` | Référence à l'utilisateur (`public.users.id`). |
| `document_type` | `text` | Type de document (ex: `passport`, `id_card`). |
| `document_url` | `text` | URL du fichier stocké dans Supabase Storage. |
| `status` | `text` | Statut du document (`En attente`, `Validé`, `Rejeté`). |
| `created_at` | `timestamptz` | Date de soumission du document. |

**Politiques de Sécurité (RLS) :**
-   **Admins :** Accès complet (lecture, écriture, suppression) à tous les documents.
-   **Clients :** Accès complet uniquement à leurs propres documents.

---

### Table `public.documents`

Table générique pour stocker d'autres types de documents que les clients pourraient téléverser.

**Colonnes :**
| Colonne | Type | Description |
| :--- | :--- | :--- |
| `id` | `uuid` | Identifiant unique du document. |
| `client_id` | `uuid` | Référence au client (`public.users.id`). |
| `document_name` | `text` | Nom du document. |
| `document_path` | `text` | Chemin du fichier dans Supabase Storage. |
| `status` | `varchar` | Statut du document (ex: `pending`, `approved`). |
| `uploaded_by` | `uuid` | Référence à l'utilisateur qui a téléversé le fichier. |

**Politiques de Sécurité (RLS) :**
-   **Admins :** Accès complet à tous les documents.
-   **Clients :** Peuvent gérer (voir, ajouter, mettre à jour, supprimer) uniquement leurs propres documents.

---

### Table `public.payments`

Enregistre toutes les transactions de paiement effectuées par les clients.

**Colonnes :**
| Colonne | Type | Description |
| :--- | :--- | :--- |
| `id` | `uuid` | Identifiant unique du paiement. |
| `client_id` | `uuid` | Référence au client (`public.users.id`). |
| `amount` | `numeric` | Montant du paiement. |
| `status` | `varchar` | Statut du paiement (ex: `completed`, `failed`). |
| `transaction_id` | `varchar` | ID de la transaction (ex: de Stripe). |
| `created_at` | `timestamptz` | Date du paiement. |

**Politiques de Sécurité (RLS) :**
-   **Admins :** Accès complet à tous les paiements.
-   **Clients :** Peuvent gérer uniquement leurs propres paiements.

---

### Table `public.notifications`

Stocke les notifications envoyées aux clients (par exemple, par les administrateurs).

**Colonnes :**
| Colonne | Type | Description |
| :--- | :--- | :--- |
| `id` | `uuid` | Identifiant unique de la notification. |
| `client_id` | `uuid` | Référence au client (`public.users.id`). |
| `message` | `text` | Contenu de la notification. |
| `status` | `varchar` | Statut (`unread`, `read`). |
| `priority` | `varchar` | Priorité (`normal`, `high`). |
| `created_at` | `timestamptz` | Date de création. |

**Politiques de Sécurité (RLS) :**
-   **Admins :** Accès complet à toutes les notifications.
-   **Clients :** Peuvent lire et marquer comme lues leurs propres notifications.

## Fonctions de la Base de Données

### `handle_new_user()`

Cette fonction est un **trigger** qui s'exécute automatiquement après la création d'un nouvel utilisateur dans `auth.users`.

**Action :**
Elle copie les informations de l'utilisateur depuis `auth.users` (y compris les métadonnées comme le nom, le plan, etc.) et crée une nouvelle entrée correspondante dans la table `public.users`. Cela permet de séparer les données d'authentification des données de profil public tout en les gardant synchronisées.

## Supabase Storage

Le stockage de fichiers est utilisé pour conserver en toute sécurité les documents téléversés par les utilisateurs.

-   **`identity-documents` (Bucket) :** Contient les fichiers des documents d'identité.
-   **`client-documents` (Bucket) :** Contient les autres documents téléversés par les clients.

Les politiques de sécurité sur les buckets garantissent que seuls les utilisateurs autorisés (le propriétaire du fichier ou un administrateur) peuvent accéder aux fichiers.
