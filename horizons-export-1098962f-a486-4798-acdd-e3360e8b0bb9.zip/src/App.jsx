import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import ClientDashboard from '@/pages/ClientDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import DocumentsPage from '@/pages/DocumentsPage';
import PaymentsPage from '@/pages/PaymentsPage';
import SettingsPage from '@/pages/SettingsPage';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import AdminClientsPage from '@/pages/AdminClientsPage';
import AdminClientProfilePage from '@/pages/AdminClientProfilePage';
import RegistrationSuccessPage from '@/pages/RegistrationSuccessPage';
import AuthCallbackPage from '@/pages/AuthCallbackPage';
import AdminAnalyticsPage from '@/pages/AdminAnalyticsPage';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Helmet>
          <title>MK COMPANY - Création de LLC Américaines</title>
          <meta name="description" content="Créez votre LLC américaine facilement avec MK COMPANY. Accès aux comptes bancaires US, PayPal Business et Stripe. Service professionnel et rapide." />
        </Helmet>
        <div className="min-h-screen bg-slate-900">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/registration-success" element={<RegistrationSuccessPage />} />
            <Route path="/auth/callback" element={<AuthCallbackPage />} />
            
            {/* Client Routes */}
            <Route path="/client/dashboard" element={<ProtectedRoute><ClientDashboard /></ProtectedRoute>} />
            <Route path="/client/documents" element={<ProtectedRoute><DocumentsPage /></ProtectedRoute>} />
            <Route path="/client/payments" element={<ProtectedRoute><PaymentsPage /></ProtectedRoute>} />
            <Route path="/client/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
            
            {/* Admin Routes */}
            <Route path="/admin/dashboard" element={<ProtectedRoute adminOnly={true}><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/clients" element={<ProtectedRoute adminOnly={true}><AdminClientsPage /></ProtectedRoute>} />
            <Route path="/admin/clients/:id" element={<ProtectedRoute adminOnly={true}><AdminClientProfilePage /></ProtectedRoute>} />
            <Route path="/admin/analytics" element={<ProtectedRoute adminOnly={true}><AdminAnalyticsPage /></ProtectedRoute>} />

          </Routes>
          <Toaster />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;