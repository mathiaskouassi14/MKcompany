import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, ChevronUp, Mail, Phone, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const [openSections, setOpenSections] = useState({
    services: false,
    legal: false,
    contact: false
  });

  const toggleSection = (section) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const footerSections = [
    {
      id: 'services',
      title: 'Services',
      links: [
        { name: 'Création LLC', href: '#' },
        { name: 'Compte bancaire US', href: '#' },
        { name: 'PayPal Business', href: '#' },
        { name: 'Configuration Stripe', href: '#' }
      ]
    },
    {
      id: 'legal',
      title: 'Légal',
      links: [
        { name: 'Mentions légales', href: '#' },
        { name: 'CGU', href: '#' },
        { name: 'Politique de confidentialité', href: '#' },
        { name: 'Cookies', href: '#' }
      ]
    },
    {
      id: 'contact',
      title: 'Contact',
      links: [
        { name: 'Support client', href: '#', icon: Mail },
        { name: '+1 (555) 123-4567', href: 'tel:+15551234567', icon: Phone },
        { name: 'New York, USA', href: '#', icon: MapPin }
      ]
    }
  ];

  return (
    <footer className="bg-slate-800 border-t border-slate-700">
      <div className="container mx-auto px-4 py-12">
        {/* Desktop Footer */}
        <div className="hidden md:block">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <Link to="/" className="flex items-center space-x-2">
                <img
                  src="https://i.ibb.co/KjbYWZCv/Gemini-Generated-Image-as4dw1as4dw1as4d-removebg-preview.png"
                  alt="MK COMPANY"
                  className="h-8 w-auto"
                />
                <span className="text-lg font-poppins font-bold text-white">
                  MK COMPANY
                </span>
              </Link>
              <p className="text-slate-400 text-sm">
                Votre partenaire de confiance pour la création de LLC américaines. 
                Simplifiez votre expansion internationale.
              </p>
            </div>

            {/* Footer Sections */}
            {footerSections.map((section) => (
              <div key={section.id} className="space-y-4">
                <h3 className="text-white font-poppins font-semibold">
                  {section.title}
                </h3>
                <ul className="space-y-2">
                  {section.links.map((link) => (
                    <li key={link.name}>
                      <a
                        href={link.href}
                        className="text-slate-400 hover:text-emerald-400 transition-colors text-sm flex items-center space-x-2"
                      >
                        {link.icon && <link.icon size={16} />}
                        <span>{link.name}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Footer */}
        <div className="md:hidden space-y-6">
          {/* Company Info */}
          <div className="text-center space-y-4">
            <Link to="/" className="inline-flex items-center space-x-2">
              <img
                src="https://i.ibb.co/KjbYWZCv/Gemini-Generated-Image-as4dw1as4dw1as4d-removebg-preview.png"
                alt="MK COMPANY"
                className="h-8 w-auto"
              />
              <span className="text-lg font-poppins font-bold text-white">
                MK COMPANY
              </span>
            </Link>
            <p className="text-slate-400 text-sm">
              Votre partenaire de confiance pour la création de LLC américaines.
            </p>
          </div>

          {/* Collapsible Sections */}
          {footerSections.map((section) => (
            <div key={section.id} className="border-b border-slate-700 pb-4">
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between text-white font-poppins font-semibold py-2"
              >
                <span>{section.title}</span>
                {openSections[section.id] ? (
                  <ChevronUp size={20} />
                ) : (
                  <ChevronDown size={20} />
                )}
              </button>
              
              {openSections[section.id] && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-2"
                >
                  <ul className="space-y-2">
                    {section.links.map((link) => (
                      <li key={link.name}>
                        <a
                          href={link.href}
                          className="text-slate-400 hover:text-emerald-400 transition-colors text-sm flex items-center space-x-2"
                        >
                          {link.icon && <link.icon size={16} />}
                          <span>{link.name}</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </div>
          ))}
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-slate-700 text-center">
          <p className="text-slate-400 text-sm">
            © 2024 MK COMPANY. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;