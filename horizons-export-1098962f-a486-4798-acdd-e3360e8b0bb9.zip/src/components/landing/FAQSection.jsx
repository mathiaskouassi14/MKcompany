import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FAQSection = () => {
  const [openItems, setOpenItems] = useState([0, 1]); // First two items open by default
  const [showAll, setShowAll] = useState(false);

  const faqs = [
    {
      question: 'Combien de temps faut-il pour créer une LLC ?',
      answer: 'Le processus de création prend généralement 7 à 10 jours ouvrés. Vous recevrez des mises à jour régulières sur l\'avancement de votre dossier.'
    },
    {
      question: 'Puis-je ouvrir un compte bancaire américain avec ma LLC ?',
      answer: 'Oui, absolument ! Nous vous aidons à ouvrir un compte bancaire américain. C\'est inclus dans nos plans Professional et Premium.'
    },
    {
      question: 'Quels documents dois-je fournir ?',
      answer: 'Vous devez fournir une pièce d\'identité valide (passeport ou carte d\'identité), un justificatif de domicile récent, et remplir notre formulaire de demande.'
    },
    {
      question: 'Y a-t-il des frais cachés ?',
      answer: 'Non, nos tarifs sont transparents. Le prix affiché inclut tous les frais de création, les documents légaux, et les services mentionnés dans chaque plan.'
    }
  ];

  const toggleItem = (index) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const visibleFaqs = showAll ? faqs : faqs.slice(0, 2);
  const hiddenFaqs = faqs.slice(2);

  return (
    <section id="faq" className="py-20 bg-slate-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
            Questions fréquentes
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Trouvez les réponses aux questions les plus courantes sur la création de LLC américaine.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {/* Always visible FAQs */}
          <div className="space-y-4">
            {visibleFaqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-effect rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => toggleItem(index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-700/30 transition-colors"
                >
                  <h3 className="font-poppins font-semibold text-white pr-4">
                    {faq.question}
                  </h3>
                  {openItems.includes(index) ? (
                    <ChevronUp className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  )}
                </button>
                
                {openItems.includes(index) && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-4"
                  >
                    <p className="text-slate-300 leading-relaxed">
                      {faq.answer}
                    </p>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>

          {/* Expandable FAQs */}
          {showAll && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.5 }}
              className="space-y-4 mt-4"
            >
              {hiddenFaqs.map((faq, index) => {
                const actualIndex = index + 2; // Adjust index for hidden items
                return (
                  <div
                    key={actualIndex}
                    className="glass-effect rounded-xl overflow-hidden"
                  >
                    <button
                      onClick={() => toggleItem(actualIndex)}
                      className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-700/30 transition-colors"
                    >
                      <h3 className="font-poppins font-semibold text-white pr-4">
                        {faq.question}
                      </h3>
                      {openItems.includes(actualIndex) ? (
                        <ChevronUp className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                      )}
                    </button>
                    
                    {openItems.includes(actualIndex) && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="px-6 pb-4"
                      >
                        <p className="text-slate-300 leading-relaxed">
                          {faq.answer}
                        </p>
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </motion.div>
          )}

          {/* Show More/Less Button */}
          <div className="text-center mt-8">
            <Button
              onClick={() => setShowAll(!showAll)}
              variant="outline"
              className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white"
            >
              {showAll ? 'Afficher moins' : 'Afficher plus de questions'}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;