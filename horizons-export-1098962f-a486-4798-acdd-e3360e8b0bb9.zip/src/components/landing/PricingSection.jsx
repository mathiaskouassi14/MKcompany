import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Check, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PricingSection = () => {
  const plans = [
    {
      name: 'Starter',
      price: '$1,200',
      description: 'Parfait pour débuter',
      features: [
        'Création LLC officielle',
        'EIN (numéro fiscal)',
        'Documents légaux',
        'Support email',
        'Guide de démarrage'
      ],
      popular: false
    },
    {
      name: 'Professional',
      price: '$1,800',
      description: 'Le plus populaire',
      features: [
        'Tout du plan Starter',
        'Compte bancaire US',
        'PayPal Business',
        'Support prioritaire',
        'Consultation 1h',
        'Adresse commerciale'
      ],
      popular: true
    },
    {
      name: 'Premium',
      price: '$2,500',
      description: 'Solution complète',
      features: [
        'Tout du plan Professional',
        'Configuration Stripe',
        'Comptabilité 3 mois',
        'Support téléphonique',
        'Consultation illimitée',
        'Service VIP'
      ],
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-slate-800/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
            Choisissez votre plan
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Des tarifs transparents pour tous vos besoins de création de LLC américaine.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className={`relative glass-effect rounded-2xl p-8 ${
                plan.popular 
                  ? 'border-2 border-emerald-500 shadow-2xl shadow-emerald-500/20' 
                  : 'border border-slate-600'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-4 py-2 rounded-full text-sm font-medium flex items-center space-x-1">
                    <Star className="w-4 h-4" />
                    <span>Plus populaire</span>
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-poppins font-bold text-white mb-2">
                  {plan.name}
                </h3>
                <p className="text-slate-400 mb-4">{plan.description}</p>
                <div className="text-4xl font-poppins font-bold text-white mb-2">
                  {plan.price}
                </div>
                <p className="text-slate-400 text-sm">Paiement unique</p>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    <span className="text-slate-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link to="/register" className="block">
                <Button 
                  className={`w-full py-3 font-semibold ${
                    plan.popular
                      ? 'bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white'
                      : 'bg-slate-700 hover:bg-slate-600 text-white'
                  }`}
                >
                  Choisir ce plan
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-slate-400">
            Tous nos plans incluent une garantie satisfait ou remboursé de 30 jours
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default PricingSection;