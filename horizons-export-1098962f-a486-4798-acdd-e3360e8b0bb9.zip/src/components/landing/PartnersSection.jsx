import React from 'react';
import { motion } from 'framer-motion';

const PartnersSection = () => {
  const partners = [
    {
      name: 'Y Combinator',
      logo: 'https://i.ibb.co/1tzRpr9r/Is-Y-Worth-It-2-removebg-preview.png',
      description: 'Accélérateur de startups'
    },
    {
      name: 'HubSpot',
      logo: 'https://i.ibb.co/8LtGfDwy/Hubspot-Logo-img-1-removebg-preview.png',
      description: 'Plateforme CRM'
    },
    {
      name: 'Nexus',
      logo: 'https://i.ibb.co/TxMvCYwP/5940629705780741548-120-removebg-preview.png',
      description: 'Services financiers'
    },
    {
      name: 'Hustle Fund',
      logo: 'https://i.ibb.co/bgxGBJZM/5940629705780741551-120-removebg-preview.png',
      description: 'Fonds d\'investissement'
    }
  ];

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/20 via-slate-900 to-blue-900/20 animate-particles opacity-30"></div>
      
      {/* Floating Particles */}
      <div className="absolute inset-0">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-emerald-400 rounded-full opacity-20 animate-particles"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 2}s`,
              animationDuration: `${20 + Math.random() * 10}s`
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
            Soutenu par les meilleurs
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Nous collaborons avec les leaders de l'industrie pour vous offrir le meilleur service.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
          {partners.map((partner, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: '0 0 30px rgba(16, 185, 129, 0.3)'
              }}
              className="glass-effect rounded-xl p-6 text-center group hover:border-emerald-500/30 transition-all duration-300"
            >
              <div className="mb-4 flex items-center justify-center h-16">
                <img
                  src={partner.logo}
                  alt={partner.name}
                  className="max-h-12 w-auto object-contain filter brightness-0 invert group-hover:filter-none transition-all duration-300"
                />
              </div>
              <h3 className="font-poppins font-semibold text-white mb-1 text-sm">
                {partner.name}
              </h3>
              <p className="text-slate-400 text-xs">
                {partner.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-slate-400">
            Rejoignez plus de 500+ entrepreneurs qui nous font confiance
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default PartnersSection;