import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const SuccessStoriesSection = () => {
  const testimonials = [
    {
      name: 'Ahmed Benali',
      role: 'E-commerce Entrepreneur',
      image: 'https://i.ibb.co/tTzRhYG3/istockphoto-1522377399-612x612.jpg',
      content: 'Grâce à MK COMPANY, j\'ai pu créer ma LLC et ouvrir mon compte PayPal Business en moins de 10 jours. Le service client est exceptionnel !',
      rating: 5
    },
    {
      name: 'Sarah Dubois',
      role: 'Consultante Marketing',
      image: 'https://i.ibb.co/93m6gQqY/istockphoto-1571704741-612x612.jpg',
      content: 'Le processus était si simple ! Maintenant je peux accepter des paiements Stripe directement depuis les États-Unis. Merci MK COMPANY !',
      rating: 5
    },
    {
      name: 'Marc Kouassi',
      role: 'Développeur SaaS',
      image: 'https://i.ibb.co/ycf1ndr9/young-african-businessman-working-office-laptop-make-notice-notebook-1296x700.jpg',
      content: 'Excellent service ! Ma LLC a été créée rapidement et j\'ai maintenant accès au marché américain. Je recommande vivement !',
      rating: 5
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-slate-800/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
            Nos clients témoignent
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Découvrez les success stories de nos entrepreneurs qui ont fait confiance à MK COMPANY.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="glass-effect rounded-xl p-6 relative"
            >
              {/* Quote Icon */}
              <div className="absolute -top-3 -left-3 w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center">
                <Quote className="w-4 h-4 text-white" />
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>

              {/* Content */}
              <p className="text-slate-300 mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center space-x-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-poppins font-semibold text-white">
                    {testimonial.name}
                  </h4>
                  <p className="text-slate-400 text-sm">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <div className="inline-flex items-center space-x-4 text-emerald-400">
            <div className="flex items-center space-x-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-current" />
              ))}
            </div>
            <span className="text-white font-semibold">4.9/5</span>
            <span className="text-slate-400">basé sur 500+ avis</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SuccessStoriesSection;