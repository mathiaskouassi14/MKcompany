import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, DollarSign, Globe, Shield, TrendingUp, Users } from 'lucide-react';

const WhyLLCSection = () => {
  const benefits = [
    {
      icon: DollarSign,
      title: 'Avantages fiscaux',
      description: 'Optimisation fiscale et déductions d\'entreprise'
    },
    {
      icon: Shield,
      title: 'Protection juridique',
      description: 'Séparation des actifs personnels et professionnels'
    },
    {
      icon: Globe,
      title: 'Marché américain',
      description: 'Accès direct au plus grand marché mondial'
    },
    {
      icon: TrendingUp,
      title: 'Crédibilité',
      description: 'Image professionnelle renforcée'
    },
    {
      icon: Users,
      title: 'Partenariats',
      description: 'Facilite les collaborations internationales'
    },
    {
      icon: CheckCircle,
      title: 'Simplicité',
      description: 'Structure flexible et facile à gérer'
    }
  ];

  return (
    <section className="py-20 bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative">
              <img 
                className="rounded-2xl shadow-2xl animate-float w-full h-auto" 
                alt="LLC américaine - Expansion internationale"
               src="https://images.unsplash.com/photo-1612278920639-cfbae3835fee" />
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 to-transparent rounded-2xl"></div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
                Pourquoi une LLC américaine ?
              </h2>
              <p className="text-xl text-slate-300 leading-relaxed">
                Découvrez les avantages uniques d'une LLC américaine pour développer 
                votre activité à l'international.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-3"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
                    <benefit.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-poppins font-semibold text-white mb-1">
                      {benefit.title}
                    </h3>
                    <p className="text-slate-400 text-sm">
                      {benefit.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyLLCSection;