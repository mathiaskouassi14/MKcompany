import React from 'react';
import { motion } from 'framer-motion';
import { FileText, CreditCard, CheckCircle } from 'lucide-react';

const ProcessSection = () => {
  const steps = [
    {
      icon: FileText,
      title: 'Inscription',
      description: 'Remplissez notre formulaire simple et téléchargez vos documents.',
      step: '01'
    },
    {
      icon: CreditCard,
      title: 'Paiement',
      description: 'Choisissez votre plan et effectuez le paiement sécurisé.',
      step: '02'
    },
    {
      icon: CheckCircle,
      title: 'Création',
      description: 'Nous créons votre LLC et configurons tous vos services.',
      step: '03'
    }
  ];

  return (
    <section className="py-20 bg-slate-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-poppins font-bold text-white mb-4">
            Comment ça marche ?
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Un processus simple en 3 étapes pour créer votre LLC américaine.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="relative text-center"
              >
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {step.step}
                </div>

                {/* Card */}
                <div className="glass-effect rounded-xl p-8 h-full">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 rounded-xl mb-6">
                    <step.icon className="w-8 h-8 text-emerald-400" />
                  </div>
                  
                  <h3 className="text-xl font-poppins font-semibold text-white mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-slate-400 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Arrow (except for last step) */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <div className="w-8 h-0.5 bg-gradient-to-r from-emerald-500 to-emerald-600"></div>
                    <div className="absolute -right-1 -top-1 w-0 h-0 border-l-4 border-l-emerald-500 border-t-2 border-t-transparent border-b-2 border-b-transparent"></div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-slate-400 mb-4">
            Délai moyen de création : 7 jours ouvrés
          </p>
          <div className="inline-flex items-center space-x-2 text-emerald-400">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">Suivi en temps réel inclus</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ProcessSection;