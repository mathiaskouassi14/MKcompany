import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Building2, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const DashboardStats = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    llcStatus: 'Chargement...',
    progress: 0,
    docsValidated: 0,
    docsTotal: 0,
    actionsRequired: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      if (!user) return;
      setLoading(true);

      const { data: documents, error } = await supabase
        .from('documents')
        .select('status')
        .eq('client_id', user.id);

      if (error) {
        console.error('Error fetching document stats:', error);
        setLoading(false);
        return;
      }

      const docsTotal = documents.length;
      const docsValidated = documents.filter(d => d.status === 'downloaded' || d.status === 'available').length;
      const actionsRequired = documents.filter(d => d.status === 'pending').length;
      
      // This is a simplified progress calculation. A more complex logic could be implemented.
      const progress = docsTotal > 0 ? Math.round((docsValidated / docsTotal) * 100) : 0;
      
      let llcStatus = 'En attente';
      if (progress > 0 && progress < 100) llcStatus = 'En cours';
      if (progress === 100) llcStatus = 'Finalisé';

      setStats({
        llcStatus,
        progress,
        docsValidated,
        docsTotal,
        actionsRequired,
      });

      setLoading(false);
    };

    fetchStats();
  }, [user]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array(4).fill(0).map((_, index) => (
          <div key={index} className="glass-effect rounded-xl p-6 h-36 flex items-center justify-center">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          </div>
        ))}
      </div>
    );
  }

  const statItems = [
    {
      title: 'Statut LLC',
      value: stats.llcStatus,
      icon: Building2,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
      description: 'Création de votre société'
    },
    {
      title: 'Progression',
      value: `${stats.progress}%`,
      icon: Clock,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      description: 'Avancement global'
    },
    {
      title: 'Documents',
      value: `${stats.docsValidated}/${stats.docsTotal}`,
      icon: CheckCircle,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-400/10',
      description: 'Disponibles'
    },
    {
      title: 'Actions requises',
      value: stats.actionsRequired,
      icon: AlertCircle,
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
      description: 'Documents en attente'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statItems.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          className="glass-effect rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-poppins font-bold text-white mb-1">
              {stat.value}
            </h3>
            <p className="text-slate-400 text-sm mb-1">{stat.title}</p>
            <p className="text-xs text-slate-500">{stat.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default DashboardStats;