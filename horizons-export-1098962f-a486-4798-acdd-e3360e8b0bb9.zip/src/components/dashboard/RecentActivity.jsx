import React from 'react';
import { motion } from 'framer-motion';
import { FileText, User, CreditCard, CheckCircle } from 'lucide-react';

const RecentActivity = () => {
  const activities = [
    {
      type: 'user',
      title: 'Nouveau client inscrit',
      description: 'Lisa Martin - Plan Professional',
      time: '2h',
      icon: User,
      color: 'text-blue-400'
    },
    {
      type: 'document',
      title: 'Document validé',
      description: 'Articles of Organization - Ahmed B.',
      time: '4h',
      icon: FileText,
      color: 'text-emerald-400'
    },
    {
      type: 'payment',
      title: 'Paiement reçu',
      description: '$1,800 - Sarah Dubois',
      time: '6h',
      icon: CreditCard,
      color: 'text-yellow-400'
    },
    {
      type: 'completion',
      title: 'LLC créée',
      description: 'TechStart LLC - Marc K.',
      time: '1j',
      icon: CheckCircle,
      color: 'text-purple-400'
    },
    {
      type: 'user',
      title: 'Nouveau client inscrit',
      description: 'Emma Wilson - Plan Starter',
      time: '1j',
      icon: User,
      color: 'text-blue-400'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="glass-effect rounded-xl p-6"
    >
      <h2 className="text-xl font-poppins font-semibold text-white mb-6">
        Activité récente
      </h2>

      <div className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className="flex items-start space-x-3">
            <div className="p-2 bg-slate-800 rounded-lg">
              <activity.icon className={`w-4 h-4 ${activity.color}`} />
            </div>
            
            <div className="flex-1">
              <h3 className="font-medium text-white text-sm">
                {activity.title}
              </h3>
              <p className="text-slate-400 text-xs mt-1">
                {activity.description}
              </p>
              <span className="text-slate-500 text-xs">
                Il y a {activity.time}
              </span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default RecentActivity;