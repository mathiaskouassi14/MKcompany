import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';

const StatusWidget = () => {
  const steps = [
    { name: 'Documents soumis', status: 'completed', date: '15 Jan 2024' },
    { name: 'Vérification', status: 'completed', date: '16 Jan 2024' },
    { name: 'Création LLC', status: 'current', date: 'En cours' },
    { name: 'Compte bancaire', status: 'pending', date: 'À venir' },
    { name: 'Configuration finale', status: 'pending', date: 'À venir' }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'current':
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'pending':
        return <div className="w-5 h-5 border-2 border-slate-600 rounded-full" />;
      default:
        return <AlertCircle className="w-5 h-5 text-red-400" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="glass-effect rounded-xl p-6"
    >
      <h2 className="text-xl font-poppins font-semibold text-white mb-6">
        Statut de création
      </h2>

      <div className="space-y-4">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center space-x-4">
            {getStatusIcon(step.status)}
            
            <div className="flex-1">
              <h3 className={`font-medium ${
                step.status === 'completed' ? 'text-white' :
                step.status === 'current' ? 'text-yellow-400' :
                'text-slate-400'
              }`}>
                {step.name}
              </h3>
              <p className="text-sm text-slate-500">{step.date}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
        <p className="text-emerald-400 text-sm">
          <strong>Prochaine étape :</strong> Finalisation des documents LLC
        </p>
        <p className="text-slate-400 text-xs mt-1">
          Délai estimé : 2-3 jours ouvrés
        </p>
      </div>
    </motion.div>
  );
};

export default StatusWidget;