import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const initialNotifications = [
  {
    id: 1,
    type: 'success',
    title: 'Document validé',
    message: 'Votre pièce d\'identité a été approuvée',
    time: '2h',
    icon: CheckCircle,
    read: false,
  },
  {
    id: 2,
    type: 'warning',
    title: 'Action requise',
    message: 'Veuillez fournir un justificatif de domicile',
    time: '1j',
    icon: AlertCircle,
    read: false,
  },
  {
    id: 3,
    type: 'info',
    title: 'Mise à jour',
    message: 'Votre LLC est en cours de traitement',
    time: '2j',
    icon: Info,
    read: true,
  }
];

const NotificationsWidget = () => {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setNotifications(initialNotifications);
      setLoading(false);
    }, 1200);
  }, []);

  const getNotificationColor = (type) => {
    switch (type) {
      case 'success': return 'text-emerald-400';
      case 'warning': return 'text-yellow-400';
      case 'info': return 'text-blue-400';
      default: return 'text-slate-400';
    }
  };

  const handleMarkAsRead = (id) => {
    setNotifications(
      notifications.map(n => n.id === id ? { ...n, read: true } : n)
    );
    toast({
      title: "Notification marquée comme lue",
      variant: "default",
      className: "bg-slate-800 border-slate-700 text-white"
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
      className="glass-effect rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-poppins font-semibold text-white">
          Notifications
        </h2>
        <Bell className="w-5 h-5 text-slate-400" />
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center text-slate-400">Chargement...</div>
        ) : notifications.length === 0 ? (
          <div className="text-center text-slate-400">Aucune notification.</div>
        ) : (
          notifications.sort((a, b) => a.read - b.read).map((notification) => (
            <div
              key={notification.id}
              className={`p-4 bg-slate-800/50 rounded-lg border border-slate-700 transition-opacity ${notification.read ? 'opacity-60' : 'opacity-100'}`}
            >
              <div className="flex items-start space-x-3">
                <notification.icon className={`w-5 h-5 mt-0.5 ${getNotificationColor(notification.type)}`} />
                
                <div className="flex-1">
                  <h3 className="font-medium text-white mb-1">
                    {notification.title}
                  </h3>
                  <p className="text-sm text-slate-400 mb-2">
                    {notification.message}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                      Il y a {notification.time}
                    </span>
                    {!notification.read && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleMarkAsRead(notification.id)}
                        className="text-xs text-emerald-400 hover:text-emerald-300 h-auto p-1"
                      >
                        Marquer comme lu
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="mt-6 text-center">
        <Button
          variant="outline"
          size="sm"
          onClick={() => toast({
            title: "🚧 Fonctionnalité en développement",
            description: "Voir toutes les notifications n'est pas encore implémenté—mais ne vous inquiétez pas ! Vous pouvez le demander dans votre prochain message ! 🚀"
          })}
          className="border-slate-600 text-slate-300 hover:bg-slate-700"
        >
          Voir toutes les notifications
        </Button>
      </div>
    </motion.div>
  );
};

export default NotificationsWidget;