import React from 'react';
import { motion } from 'framer-motion';
import { Users, Building2, DollarSign, TrendingUp } from 'lucide-react';

const AdminStats = ({ stats }) => {
  const statItems = [
    {
      title: 'Clients actifs',
      value: stats.clients,
      icon: Users,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
    {
      title: 'LLC créées',
      value: stats.llcCreated,
      icon: Building2,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-400/10',
    },
    {
      title: 'Revenus',
      value: `$${stats.revenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
    },
    {
      title: 'Nouveaux Clients (30j)',
      value: stats.newClients,
      icon: TrendingUp,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statItems.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          className="glass-effect rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-poppins font-bold text-white mb-1">
              {stat.value}
            </h3>
            <p className="text-slate-400 text-sm">{stat.title}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default AdminStats;