import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Eye, CheckCircle, Loader2, ShieldAlert, ShieldCheck, ShieldX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useNavigate } from 'react-router-dom';

const RecentDocuments = ({ limit, showViewAll = true }) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [identityDocuments, setIdentityDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const fetchAllDocuments = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    
    const fetchAdminDocs = supabase
      .from('documents')
      .select('*')
      .eq('client_id', user.id)
      .order('upload_date', { ascending: false });

    const fetchIdDocs = supabase
      .from('identity_documents')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    const [{ data: adminDocs, error: adminDocsError }, { data: idDocs, error: idDocsError }] = await Promise.all([fetchAdminDocs, fetchIdDocs]);

    if (adminDocsError || idDocsError) {
      console.error('Error fetching documents:', adminDocsError || idDocsError);
      toast({
        variant: 'destructive',
        title: 'Erreur',
        description: 'Impossible de charger les documents.',
      });
    } else {
      setDocuments(adminDocs || []);
      setIdentityDocuments(idDocs || []);
    }
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    if (user) {
      fetchAllDocuments();

      const adminDocListener = supabase
        .channel(`public:documents:client_id=eq.${user.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'documents', filter: `client_id=eq.${user.id}` }, 
          () => fetchAllDocuments()
        )
        .subscribe();
        
      const idDocListener = supabase
        .channel(`public:identity_documents:user_id=eq.${user.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'identity_documents', filter: `user_id=eq.${user.id}` }, 
          () => fetchAllDocuments()
        )
        .subscribe();

      return () => {
        supabase.removeChannel(adminDocListener);
        supabase.removeChannel(idDocListener);
      };
    }
  }, [user, fetchAllDocuments]);

  const getStatusInfo = (status, type) => {
    if (type === 'admin') {
      return { icon: <CheckCircle className="w-5 h-5 text-emerald-400" />, text: 'Document disponible', color: 'text-emerald-400' };
    } else { // identity
      switch (status) {
        case 'En attente':
          return { icon: <ShieldAlert className="w-5 h-5 text-yellow-400" />, text: 'En cours de validation', color: 'text-yellow-400' };
        case 'Validé':
          return { icon: <ShieldCheck className="w-5 h-5 text-emerald-400" />, text: 'Document validé', color: 'text-emerald-400' };
        case 'Rejeté':
          return { icon: <ShieldX className="w-5 h-5 text-red-400" />, text: 'Document rejeté', color: 'text-red-400' };
        default:
          return { icon: <FileText className="w-5 h-5 text-slate-400" />, text: 'Inconnu', color: 'text-slate-400' };
      }
    }
  };

  const handlePreview = async (doc, storage) => {
    if (doc.type === 'identity' && (doc.status === 'En attente' || doc.status === 'Rejeté')) {
      toast({
        variant: 'destructive',
        title: 'Document non disponible',
        description: "Ce document n'est pas encore validé. Veuillez patienter.",
      });
      return;
    }
    
    const { data, error } = await supabase.storage.from(storage).createSignedUrl(doc.document_url || doc.document_path, 60);
    if (error) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de générer l\'aperçu.' });
      return;
    }

    setSelectedDoc({ ...doc, signedUrl: data.signedUrl });
    setIsPreviewOpen(true);
  };

  const handleDownload = async (doc, storage) => {
    if (doc.type === 'identity' && (doc.status === 'En attente' || doc.status === 'Rejeté')) {
      toast({
        variant: 'destructive',
        title: 'Téléchargement impossible',
        description: "Ce document n'est pas encore validé.",
      });
      return;
    }

    toast({
      title: "Téléchargement en cours...",
      description: `Le document "${doc.document_name || 'Pièce d\'identité'}" est en cours de téléchargement.`,
      className: "bg-slate-800 border-slate-700 text-white"
    });

    const { data, error } = await supabase.storage.from(storage).download(doc.document_url || doc.document_path);

    if (error) {
      toast({ variant: 'destructive', title: 'Erreur de téléchargement', description: error.message });
      return;
    }

    const blob = new Blob([data], { type: doc.document_type });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = doc.document_name || 'identity-document';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const allDocs = [
    ...identityDocuments.map(d => ({ ...d, type: 'identity', date: d.created_at, name: `Pièce d'identité` })),
    ...documents.map(d => ({ ...d, type: 'admin', date: d.upload_date, name: d.document_name }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const limitedDocs = limit ? allDocs.slice(0, limit) : allDocs;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="glass-effect rounded-xl p-6"
      >
        <h2 className="text-xl font-poppins font-semibold text-white mb-6">
          Documents
        </h2>

        <div className="space-y-4">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
            </div>
          ) : limitedDocs.length === 0 ? (
            <div className="text-center text-slate-400 py-10">
              Aucun document disponible pour le moment.
            </div>
          ) : (
            limitedDocs.map((doc) => {
              const statusInfo = getStatusInfo(doc.status, doc.type);
              const isActionable = doc.type === 'admin' || doc.status === 'Validé';
              const storageBucket = doc.type === 'identity' ? 'identity-documents' : 'documents';

              return (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                >
                  <div className="flex items-center space-x-4 overflow-hidden">
                    <div className="p-2 bg-slate-700 rounded-lg flex-shrink-0">
                      <FileText className="w-5 h-5 text-slate-300" />
                    </div>
                    
                    <div className="overflow-hidden">
                      <h3 className="font-medium text-white truncate">{doc.name}</h3>
                      <div className={`flex items-center space-x-2 mt-1 ${statusInfo.color}`}>
                        {statusInfo.icon}
                        <span className="text-sm">
                          {statusInfo.text} • {new Date(doc.date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePreview(doc, storageBucket)}
                      disabled={!isActionable}
                      className="text-slate-400 hover:text-white disabled:text-slate-600 disabled:cursor-not-allowed"
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDownload(doc, storageBucket)}
                      disabled={!isActionable}
                      className="text-slate-400 hover:text-white disabled:text-slate-600 disabled:cursor-not-allowed"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {showViewAll && allDocs.length > 0 && (
          <div className="mt-6 text-center">
            <Button
              variant="outline"
              onClick={() => navigate('/client/documents')}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Voir tous les documents
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-[80vw] h-[90vh] flex flex-col bg-slate-900 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>{selectedDoc?.name}</DialogTitle>
            <DialogDescription className="text-slate-400">
              Aperçu du document. Date: {selectedDoc && new Date(selectedDoc.date).toLocaleDateString()}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-grow mt-4 overflow-auto rounded-lg bg-slate-800">
            {selectedDoc?.document_type?.includes('pdf') ? (
              <iframe
                src={selectedDoc.signedUrl}
                className="w-full h-full"
                title={selectedDoc.name}
              />
            ) : (
              <img
                src={selectedDoc?.signedUrl}
                alt={selectedDoc?.name}
                className="max-w-full max-h-full object-contain mx-auto"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RecentDocuments;