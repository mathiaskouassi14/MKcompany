import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  Eye, 
  Loader2, 
  ShieldCheck, 
  ShieldAlert, 
  ShieldX, 
  Phone, 
  Mail, 
  AlertTriangle, 
  Search,
  FileText,
  CreditCard,
  Bell,
  Users,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { 
  getAllUsers, 
  searchUsers, 
  formatUserData,
  formatDate 
} from '@/lib/adminApiServices';

const ClientsList = ({ limit }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  
  // États principaux
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searching, setSearching] = useState(false);
  const [filteredClients, setFilteredClients] = useState([]);

  // Fonction pour récupérer tous les clients
  const fetchClients = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await getAllUsers();
      
      if (fetchError) {
        throw new Error(fetchError.message || 'Erreur lors de la récupération des clients');
      }

      // Formater les données et exclure les admins
      const formattedClients = data
        .map(formatUserData)
        .filter(client => client.role !== 'admin' && client.email !== 'admin@example.com');

      // Appliquer la limite si spécifiée
      const clientsToSet = limit ? formattedClients.slice(0, limit) : formattedClients;
      
      setClients(clientsToSet);
      setFilteredClients(clientsToSet);
      
    } catch (err) {
      console.error('Erreur lors du chargement des clients:', err);
      setError(err.message);
      toast({
        variant: 'destructive',
        title: 'Erreur de chargement',
        description: err.message
      });
    } finally {
      setLoading(false);
    }
  }, [limit, toast]);

  // Fonction de recherche
  const handleSearch = useCallback(async (term) => {
    if (!term.trim()) {
      setFilteredClients(clients);
      setSearching(false);
      return;
    }

    setSearching(true);
    
    try {
      const { data, error: searchError } = await searchUsers(term);
      
      if (searchError) {
        throw new Error(searchError.message);
      }

      const formattedResults = data
        .map(formatUserData)
        .filter(client => client.role !== 'admin');

      setFilteredClients(formattedResults);
      
    } catch (err) {
      console.error('Erreur lors de la recherche:', err);
      toast({
        variant: 'destructive',
        title: 'Erreur de recherche',
        description: err.message
      });
      setFilteredClients(clients); // Revenir à la liste complète en cas d'erreur
    } finally {
      setSearching(false);
    }
  }, [clients, toast]);

  // Effet pour la recherche avec délai
  useEffect(() => {
    const delayedSearch = setTimeout(() => {
      handleSearch(searchTerm);
    }, 300);

    return () => clearTimeout(delayedSearch);
  }, [searchTerm, handleSearch]);

  // Chargement initial
  useEffect(() => {
    fetchClients();
  }, [fetchClients]);

  // Fonctions utilitaires
  const getPlanName = (planKey) => {
    const plans = {
      starter: 'Starter',
      professional: 'Professional', 
      premium: 'Premium'
    };
    return plans[planKey] || 'N/A';
  };

  const getPlanColor = (planKey) => {
    const colors = {
      starter: 'text-blue-400 bg-blue-400/10',
      professional: 'text-purple-400 bg-purple-400/10',
      premium: 'text-amber-400 bg-amber-400/10'
    };
    return colors[planKey] || 'text-slate-400 bg-slate-400/10';
  };

  const getDocumentStatusFromIdentityDocs = (user) => {
    const idDocs = user.identity_documents || [];
    
    if (idDocs.length === 0) return 'Aucun';
    
    const hasValidated = idDocs.some(d => d.status === 'Validé');
    const hasPending = idDocs.some(d => d.status === 'En attente');
    const hasRejected = idDocs.some(d => d.status === 'Rejeté');
    
    if (hasValidated) return 'Validé';
    if (hasPending) return 'En attente';
    if (hasRejected) return 'Rejeté';
    return 'Aucun';
  };

  const getStatusChip = (status) => {
    switch (status) {
      case 'Validé':
        return (
          <span className="flex items-center text-emerald-400">
            <ShieldCheck className="w-4 h-4 mr-1.5" /> 
            {status}
          </span>
        );
      case 'En attente':
        return (
          <span className="flex items-center text-yellow-400">
            <ShieldAlert className="w-4 h-4 mr-1.5" /> 
            {status}
          </span>
        );
      case 'Rejeté':
        return (
          <span className="flex items-center text-red-400">
            <ShieldX className="w-4 h-4 mr-1.5" /> 
            {status}
          </span>
        );
      default:
        return <span className="text-slate-400">{status}</span>;
    }
  };

  // Rendu du contenu principal
  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
        </div>
      );
    }

    if (error) {
      return (
        <div className="text-center py-10 bg-red-900/20 rounded-lg border border-red-800/30">
          <AlertTriangle className="mx-auto h-12 w-12 text-red-400 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Erreur de chargement</h3>
          <p className="text-sm text-red-300 px-4 mb-4">{error}</p>
          <Button 
            onClick={fetchClients} 
            variant="outline"
            className="border-red-600 text-red-400 hover:bg-red-600/10"
          >
            Réessayer
          </Button>
        </div>
      );
    }

    if (filteredClients.length === 0) {
      return (
        <div className="text-center py-10">
          <Users className="mx-auto h-12 w-12 text-slate-400 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">
            {searchTerm ? 'Aucun résultat' : 'Aucun client'}
          </h3>
          <p className="text-slate-400">
            {searchTerm 
              ? `Aucun client trouvé pour "${searchTerm}"` 
              : 'Aucun client enregistré pour le moment.'
            }
          </p>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-700">
              <th className="text-left text-slate-400 font-medium py-3 px-2">Client</th>
              <th className="text-left text-slate-400 font-medium py-3 px-2 hidden md:table-cell">Entreprise</th>
              <th className="text-left text-slate-400 font-medium py-3 px-2 hidden lg:table-cell">Plan</th>
              <th className="text-left text-slate-400 font-medium py-3 px-2 hidden xl:table-cell">Statistiques</th>
              <th className="text-left text-slate-400 font-medium py-3 px-2 hidden md:table-cell">Statut ID</th>
              <th className="text-right text-slate-400 font-medium py-3 px-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.map((client) => (
              <motion.tr 
                key={client.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="border-b border-slate-700/50 hover:bg-slate-800/30 transition-colors"
              >
                {/* Informations client */}
                <td className="py-4 px-2">
                  <div>
                    <h3 className="font-medium text-white mb-1">
                      {client.fullName || 'Nom non renseigné'}
                    </h3>
                    <div className="flex items-center gap-2 text-slate-400 text-xs mb-1">
                      <Mail className="w-3 h-3" />
                      <span>{client.email}</span>
                    </div>
                    {client.phone && (
                      <div className="flex items-center gap-2 text-slate-400 text-xs">
                        <Phone className="w-3 h-3" />
                        <span>{client.phone}</span>
                      </div>
                    )}
                    <div className="text-xs text-slate-500 mt-1">
                      Inscrit le {formatDate(client.created_at)}
                    </div>
                  </div>
                </td>

                {/* Informations entreprise */}
                <td className="py-4 px-2 hidden md:table-cell">
                  <div>
                    <span className="text-slate-300 font-medium">
                      {client.llc_name || 'N/A'}
                    </span>
                    {client.formation_state && (
                      <p className="text-slate-400 text-xs capitalize mt-1">
                        {client.formation_state}
                      </p>
                    )}
                    {client.business_type && (
                      <p className="text-slate-500 text-xs mt-1">
                        {client.business_type}
                      </p>
                    )}
                  </div>
                </td>

                {/* Plan */}
                <td className="py-4 px-2 hidden lg:table-cell">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPlanColor(client.plan)}`}>
                    {getPlanName(client.plan)}
                  </span>
                </td>

                {/* Statistiques */}
                <td className="py-4 px-2 hidden xl:table-cell">
                  <div className="flex items-center gap-3 text-xs">
                    <div className="flex items-center gap-1 text-slate-400">
                      <FileText className="w-3 h-3" />
                      <span>{client.documentsCount}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-400">
                      <CreditCard className="w-3 h-3" />
                      <span>{client.paymentsCount}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-400">
                      <Bell className="w-3 h-3" />
                      <span>{client.notificationsCount}</span>
                    </div>
                  </div>
                </td>

                {/* Statut des documents d'identité */}
                <td className="py-4 px-2 hidden md:table-cell">
                  {getStatusChip(getDocumentStatusFromIdentityDocs(client))}
                </td>

                {/* Actions */}
                <td className="py-4 px-2 text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(`/admin/clients/${client.id}`)}
                    className="text-slate-400 hover:text-white hover:bg-slate-700"
                  >
                    <Eye className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Voir profil</span>
                  </Button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="glass-effect rounded-xl p-6"
    >
      {/* En-tête avec titre et recherche */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h2 className="text-xl font-poppins font-semibold text-white">
            {limit ? 'Clients récents' : 'Gestion des clients'}
          </h2>
          {!loading && (
            <p className="text-slate-400 text-sm mt-1">
              {filteredClients.length} client{filteredClients.length > 1 ? 's' : ''} 
              {searchTerm && ` trouvé${filteredClients.length > 1 ? 's' : ''} pour "${searchTerm}"`}
            </p>
          )}
        </div>

        {/* Barre de recherche (seulement si pas de limite) */}
        {!limit && (
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Rechercher un client..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-400"
            />
            {searching && (
              <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 text-emerald-400 w-4 h-4 animate-spin" />
            )}
          </div>
        )}
      </div>

      {/* Contenu principal */}
      {renderContent()}

      {/* Bouton voir tous (pour la version avec limite) */}
      {limit && clients.length > 0 && !error && (
        <div className="mt-6 text-center border-t border-slate-700 pt-6">
          <Button
            variant="outline"
            onClick={() => navigate('/admin/clients')}
            className="border-slate-600 text-slate-300 hover:bg-slate-700 hover:border-emerald-400"
          >
            <Users className="w-4 h-4 mr-2" />
            Voir tous les clients
          </Button>
        </div>
      )}
    </motion.div>
  );
};

export default ClientsList;