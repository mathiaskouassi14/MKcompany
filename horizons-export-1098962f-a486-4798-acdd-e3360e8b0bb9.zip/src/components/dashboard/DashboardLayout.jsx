import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  FileText, 
  CreditCard, 
  Settings, 
  Users, 
  BarChart3, 
  Menu, 
  X,
  LogOut,
  Bell,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const DashboardLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, signOut } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [loadingNotifications, setLoadingNotifications] = useState(true);

  const userType = user?.user_metadata?.role || 'client';

  const fetchNotifications = async () => {
    if (!user) return;
    setLoadingNotifications(true);
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('client_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching notifications:', error);
    } else {
      setNotifications(data);
    }
    setLoadingNotifications(false);
  };

  useEffect(() => {
    if (user) {
      fetchNotifications();

      const channel = supabase.channel(`notifications:${user.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `client_id=eq.${user.id}` },
          (payload) => {
            fetchNotifications();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);

  const unreadCount = notifications.filter(n => n.status === 'unread').length;

  const userInitial = user?.user_metadata?.first_name ? user.user_metadata.first_name.charAt(0).toUpperCase() : (user?.email ? user.email.charAt(0).toUpperCase() : 'U');
  const userDisplayName = user?.user_metadata?.first_name && user?.user_metadata?.last_name ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}` : (userType === 'admin' ? 'Administrateur' : 'Utilisateur');

  const clientNavItems = [
    { name: 'Dashboard', href: '/client/dashboard', icon: Home },
    { name: 'Documents', href: '/client/documents', icon: FileText },
    { name: 'Paiements', href: '/client/payments', icon: CreditCard },
    { name: 'Paramètres', href: '/client/settings', icon: Settings }
  ];

  const adminNavItems = [
    { name: 'Dashboard', href: '/admin/dashboard', icon: Home },
    { name: 'Clients', href: '/admin/clients', icon: Users },
    { name: 'Analytique', href: '/admin/analytics', icon: BarChart3 },
  ];

  const navItems = userType === 'admin' ? adminNavItems : clientNavItems;

  const handleNavClick = (href) => {
    setSidebarOpen(false);
    navigate(href);
  };

  const handleLogout = async () => {
    await signOut();
    toast({
      title: "Déconnexion réussie",
      description: "Vous allez être redirigé vers la page d'accueil."
    });
    navigate('/');
  };

  const markAsRead = async (id) => {
    const { error } = await supabase
      .from('notifications')
      .update({ status: 'read' })
      .eq('id', id);
    
    if (!error) {
      setNotifications(notifications.map(n => n.id === id ? { ...n, status: 'read' } : n));
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex">
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-800 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0`}>
        <div className="flex items-center justify-between h-16 px-4 border-b border-slate-700">
          <Link to="/" className="flex items-center space-x-2">
            <img
              src="https://i.ibb.co/KjbYWZCv/Gemini-Generated-Image-as4dw1as4dw1as4d-removebg-preview.png"
              alt="MK COMPANY"
              className="h-8 w-auto"
            />
            <span className="text-lg font-poppins font-bold text-white">
              MK COMPANY
            </span>
          </Link>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="mt-8 px-4">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const isActive = location.pathname.startsWith(item.href);
              return (
                <li key={item.name}>
                  <button
                    onClick={() => handleNavClick(item.href)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-emerald-500 text-white'
                        : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.name}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <Button
            onClick={handleLogout}
            variant="ghost"
            className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Déconnexion
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <header className="bg-slate-800 border-b border-slate-700 h-16 flex items-center justify-between px-4 lg:px-8 flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-slate-400 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1"></div>
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="relative text-slate-400 hover:text-white"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs text-white ring-2 ring-slate-800">
                      {unreadCount}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 bg-slate-800 border-slate-700 text-white">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-slate-700" />
                {loadingNotifications ? (
                  <DropdownMenuItem disabled className="flex justify-center items-center p-4">
                    <Loader2 className="w-5 h-5 animate-spin text-emerald-400" />
                  </DropdownMenuItem>
                ) : notifications.length === 0 ? (
                  <DropdownMenuItem disabled>Aucune notification</DropdownMenuItem>
                ) : (
                  notifications.slice(0, 5).map(notif => (
                    <DropdownMenuItem key={notif.id} onSelect={() => markAsRead(notif.id)} className={`flex items-start gap-3 focus:bg-slate-700 ${notif.status === 'unread' && 'bg-slate-700/50'}`}>
                      {notif.status === 'unread' && <div className="w-2 h-2 mt-1.5 rounded-full bg-emerald-400 flex-shrink-0" />}
                      <div className={notif.status === 'read' ? 'pl-5' : ''}>
                        <p className="font-medium">{notif.message}</p>
                        <p className="text-xs text-slate-400 mt-1">{new Date(notif.created_at).toLocaleString()}</p>
                      </div>
                    </DropdownMenuItem>
                  ))
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {userInitial}
                </span>
              </div>
              <div className="hidden md:block">
                <p className="text-white font-medium">
                  {userDisplayName}
                </p>
                <p className="text-slate-400 text-sm">
                  {user?.email}
                </p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default DashboardLayout;