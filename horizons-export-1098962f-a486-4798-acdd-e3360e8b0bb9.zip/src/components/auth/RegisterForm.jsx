import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Mail, Phone, Calendar, Upload, CreditCard, Building, Map, Briefcase, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const RegisterForm = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    password: '',
    confirmPassword: '',
    plan: 'professional',
    llcName: '',
    formationState: '',
    businessType: '',
    idDocument: null
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { signUp } = useAuth();

  const plans = [
    { id: 'starter', name: 'Starter', price: '$1,200' },
    { id: 'professional', name: 'Professional', price: '$1,800' },
    { id: 'premium', name: 'Premium', price: '$2,500' }
  ];

  const handleNextStep = (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Les mots de passe ne correspondent pas.",
      });
      return;
    }
    if (formData.password.length < 6) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Le mot de passe doit contenir au moins 6 caractères.",
      });
      return;
    }

    setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.idDocument) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Veuillez télécharger votre pièce d'identité.",
      });
      return;
    }
    setIsLoading(true);

    const file = formData.idDocument;
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const pendingFile = {
        dataUrl: reader.result,
        name: file.name,
        type: file.type,
      };
      localStorage.setItem('pendingFile', JSON.stringify(pendingFile));

      const { error } = await signUp(formData.email, formData.password, {
        data: {
          first_name: formData.firstName,
          last_name: formData.lastName,
          phone: formData.phone,
          date_of_birth: formData.dateOfBirth,
          plan: formData.plan,
          llc_name: formData.llcName,
          formation_state: formData.formationState,
          business_type: formData.businessType,
          role: 'client',
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`
      });

      setIsLoading(false);

      if (error) {
        if (error.message.includes("User already registered")) {
          toast({
            variant: "destructive",
            title: "Email déjà utilisé",
            description: "Cet email est déjà associé à un compte. Veuillez vous connecter ou utiliser un autre email.",
          });
          setStep(1);
        } else {
          toast({
            variant: "destructive",
            title: "Erreur d'inscription",
            description: error.message,
          });
        }
        localStorage.removeItem('pendingFile');
        return;
      }
      
      navigate('/registration-success');
    };
    reader.onerror = () => {
        toast({
            variant: "destructive",
            title: "Erreur Fichier",
            description: "Impossible de lire le fichier pour le stockage temporaire.",
        });
        setIsLoading(false);
    };
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        idDocument: file
      });
    }
  };

  const formVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 50 },
  };

  return (
    <form onSubmit={step === 1 ? handleNextStep : handleSubmit} className="space-y-6">
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-slate-300">Prénom</Label>
                <div className="relative mt-1">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="firstName" name="firstName" type="text" required value={formData.firstName} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" placeholder="John" />
                </div>
              </div>
              <div>
                <Label htmlFor="lastName" className="text-slate-300">Nom</Label>
                <div className="relative mt-1">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="lastName" name="lastName" type="text" required value={formData.lastName} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" placeholder="Doe" />
                </div>
              </div>
            </div>
            <div>
              <Label htmlFor="email" className="text-slate-300">Email</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input id="email" name="email" type="email" required value={formData.email} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" placeholder="john@example.com" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone" className="text-slate-300">Téléphone</Label>
                <div className="relative mt-1">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="phone" name="phone" type="tel" required value={formData.phone} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" placeholder="+33 1 23 45 67 89" />
                </div>
              </div>
              <div>
                <Label htmlFor="dateOfBirth" className="text-slate-300">Date de naissance</Label>
                <div className="relative mt-1">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="dateOfBirth" name="dateOfBirth" type="date" required value={formData.dateOfBirth} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="password">Mot de passe</Label>
                <div className="relative mt-1">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="password" name="password" type="password" required value={formData.password} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white" placeholder="••••••••" />
                </div>
              </div>
              <div>
                <Label htmlFor="confirmPassword">Confirmer le mot de passe</Label>
                <div className="relative mt-1">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input id="confirmPassword" name="confirmPassword" type="password" required value={formData.confirmPassword} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white" placeholder="••••••••" />
                </div>
              </div>
            </div>
            <div>
              <Label className="text-slate-300 mb-3 block">Choisissez votre plan</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {plans.map((plan) => (
                  <label key={plan.id} className={`relative flex items-center p-4 rounded-lg border cursor-pointer transition-all ${formData.plan === plan.id ? 'border-emerald-500 bg-emerald-500/10' : 'border-slate-600 bg-slate-800/50 hover:border-slate-500'}`}>
                    <input type="radio" name="plan" value={plan.id} checked={formData.plan === plan.id} onChange={handleChange} className="sr-only" />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <CreditCard className="w-4 h-4 text-emerald-400" />
                        <span className="font-semibold text-white">{plan.name}</span>
                      </div>
                      <p className="text-emerald-400 font-bold">{plan.price}</p>
                    </div>
                    {formData.plan === plan.id && (<div className="absolute top-2 right-2 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full"></div></div>)}
                  </label>
                ))}
              </div>
            </div>
            <Button type="submit" disabled={isLoading} className="w-full bg-slate-700 hover:bg-slate-600 text-white font-semibold py-3 transition-transform hover:scale-105">
              {isLoading ? (<motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />) : ('Continuer')}
            </Button>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <h2 className="text-xl font-poppins font-semibold text-white text-center">Informations pour votre LLC</h2>
            
            <div>
              <Label htmlFor="llcName" className="text-slate-300">Nom souhaité pour votre LLC</Label>
              <div className="relative mt-1">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input id="llcName" name="llcName" type="text" required value={formData.llcName} onChange={handleChange} className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500" placeholder="Ex: My Awesome Company LLC" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="formationState" className="text-slate-300">État de formation</Label>
                <div className="relative mt-1">
                  <Map className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 z-10" />
                  <Select required onValueChange={(value) => handleSelectChange('formationState', value)} value={formData.formationState}>
                    <SelectTrigger className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500">
                      <SelectValue placeholder="Sélectionnez un état" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="delaware">Delaware</SelectItem>
                      <SelectItem value="wyoming">Wyoming</SelectItem>
                      <SelectItem value="new-mexico">New Mexico</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="businessType" className="text-slate-300">Type de business</Label>
                <div className="relative mt-1">
                  <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5 z-10" />
                  <Select required onValueChange={(value) => handleSelectChange('businessType', value)} value={formData.businessType}>
                    <SelectTrigger className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500">
                      <SelectValue placeholder="Sélectionnez un type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="e-commerce">E-commerce</SelectItem>
                      <SelectItem value="consulting">Consulting</SelectItem>
                      <SelectItem value="saas">SaaS</SelectItem>
                      <SelectItem value="other">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="idDocument" className="text-slate-300">Copie passeport/pièce d'identité</Label>
              <div className="mt-1">
                <label className="flex items-center justify-center w-full h-32 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:border-slate-500 transition-colors">
                  <div className="text-center">
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-slate-400">{formData.idDocument ? formData.idDocument.name : 'Cliquez pour télécharger'}</p>
                    <p className="text-xs text-slate-500 mt-1">PDF, JPG, PNG jusqu'à 10MB</p>
                  </div>
                  <input id="idDocument" name="idDocument" type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} className="sr-only" required />
                </label>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <input type="checkbox" required className="mt-1 rounded border-slate-600 text-emerald-500 focus:ring-emerald-500 focus:ring-offset-0" />
              <p className="text-sm text-slate-400">J'accepte les <a href="#" className="text-emerald-400 hover:text-emerald-300">conditions générales</a> et la <a href="#" className="text-emerald-400 hover:text-emerald-300">politique de confidentialité</a></p>
            </div>

            <div className="flex items-center gap-4">
              <Button type="button" onClick={() => setStep(1)} variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">
                Retour
              </Button>
              <Button type="submit" disabled={isLoading} className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold py-3">
                {isLoading ? (<motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />) : ('Finaliser')}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </form>
  );
};

export default RegisterForm;