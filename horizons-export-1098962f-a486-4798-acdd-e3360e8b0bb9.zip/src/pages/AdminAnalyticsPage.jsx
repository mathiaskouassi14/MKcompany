import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, Users, FileText, PieChart } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const AdminAnalyticsPage = () => {
  const [loading, setLoading] = useState(true);
  const [analyticsData, setAnalyticsData] = useState(null);
  const [timeRange, setTimeRange] = useState(30);

  useEffect(() => {
    const fetchAnalytics = async () => {
      setLoading(true);

      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - timeRange);

      const { data: usersData, error: usersError } = await supabase.auth.admin.listUsers();
      if (usersError) {
        console.error("Error fetching users:", usersError);
        setLoading(false);
        return;
      }
      
      const clientUsers = usersData.users.filter(u => u.user_metadata?.role === 'client');
      const newSignups = clientUsers.filter(u => new Date(u.created_at) >= fromDate).length;

      const { data: documentsData, error: documentsError } = await supabase.from('documents').select('status');
      if (documentsError) {
        console.error("Error fetching documents:", documentsError);
        setLoading(false);
        return;
      }

      const docStatusCounts = documentsData.reduce((acc, doc) => {
        const status = doc.status || 'unknown';
        acc[status] = (acc[status] || 0) + 1;
        return acc;
      }, {});

      const planCounts = clientUsers.reduce((acc, user) => {
        const plan = user.user_metadata?.plan || 'unknown';
        acc[plan] = (acc[plan] || 0) + 1;
        return acc;
      }, {});

      setAnalyticsData({
        newSignups,
        docStatusCounts,
        planCounts,
        totalClients: clientUsers.length,
        totalDocuments: documentsData.length,
        totalPlans: clientUsers.length,
      });

      setLoading(false);
    };

    fetchAnalytics();
  }, [timeRange]);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  const planColors = {
    starter: 'bg-blue-500',
    professional: 'bg-emerald-500',
    premium: 'bg-purple-500',
    unknown: 'bg-slate-500',
  };

  const docStatusColors = {
    pending: 'bg-yellow-500',
    available: 'bg-blue-500',
    downloaded: 'bg-emerald-500',
    uploaded: 'bg-indigo-500',
    unknown: 'bg-slate-500',
  };

  return (
    <>
      <Helmet>
        <title>Analytique - MK COMPANY</title>
        <meta name="description" content="Analysez les données de la plateforme MK COMPANY." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-8">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">Analytique</h1>
            <p className="text-slate-400">Suivez les performances de votre plateforme.</p>
          </div>

          <div className="flex items-center gap-2">
            <p className="text-slate-300">Période :</p>
            {[5, 20, 30].map(days => (
              <Button
                key={days}
                variant={timeRange === days ? 'default' : 'outline'}
                onClick={() => setTimeRange(days)}
                className={timeRange === days ? 'bg-emerald-500 hover:bg-emerald-600' : 'border-slate-600 text-slate-300 hover:bg-slate-700'}
              >
                {days} jours
              </Button>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            <AnalyticsCard icon={Users} title={`Inscriptions (${timeRange}j)`} value={analyticsData.newSignups} />
            <AnalyticsCard icon={Users} title="Clients Totaux" value={analyticsData.totalClients} />
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ChartCard icon={FileText} title="Statut des Documents">
              {Object.keys(analyticsData.docStatusCounts).length > 0 ? (
                Object.entries(analyticsData.docStatusCounts).map(([status, count]) => (
                  <Bar key={status} label={status} value={count} total={analyticsData.totalDocuments} colorClass={docStatusColors[status]} />
                ))
              ) : <p className="text-slate-400">Aucune donnée de document.</p>}
            </ChartCard>
            <ChartCard icon={PieChart} title="Répartition des Plans">
              {Object.keys(analyticsData.planCounts).length > 0 ? (
                Object.entries(analyticsData.planCounts).map(([plan, count]) => (
                  <Bar key={plan} label={plan} value={count} total={analyticsData.totalPlans} colorClass={planColors[plan]} />
                ))
              ) : <p className="text-slate-400">Aucune donnée de plan.</p>}
            </ChartCard>
          </div>
        </div>
      </DashboardLayout>
    </>
  );
};

const AnalyticsCard = ({ icon: Icon, title, value }) => (
  <div className="glass-effect p-6 rounded-xl">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-emerald-500/10 rounded-lg">
        <Icon className="w-6 h-6 text-emerald-400" />
      </div>
      <div>
        <p className="text-slate-400 text-sm">{title}</p>
        <p className="text-2xl font-bold text-white">{value}</p>
      </div>
    </div>
  </div>
);

const ChartCard = ({ icon: Icon, title, children }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.2 }}
    className="glass-effect p-6 rounded-xl"
  >
    <div className="flex items-center gap-3 mb-6">
      <Icon className="w-5 h-5 text-emerald-400" />
      <h3 className="text-lg font-semibold text-white">{title}</h3>
    </div>
    <div className="space-y-4">{children}</div>
  </motion.div>
);

const Bar = ({ label, value, total, colorClass }) => {
  const percentage = total > 0 ? (value / total) * 100 : 0;
  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium text-slate-300 capitalize">{label}</span>
        <span className="text-sm font-bold text-white">{value}</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2.5">
        <div className={`${colorClass || 'bg-gray-400'} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
};

export default AdminAnalyticsPage;