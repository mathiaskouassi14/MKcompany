import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Mail } from 'lucide-react';

const RegistrationSuccessPage = () => {
  return (
    <>
      <Helmet>
        <title>Inscription presque terminée - MK COMPANY</title>
        <meta name="description" content="Vérifiez votre email pour finaliser votre inscription." />
      </Helmet>
      <div className="min-h-screen bg-slate-900 flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="max-w-md w-full text-center"
        >
          <div className="glass-effect rounded-2xl p-8 shadow-2xl">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5, type: 'spring', stiffness: 150 }}
            >
              <CheckCircle className="w-20 h-20 text-emerald-400 mx-auto" />
            </motion.div>
            
            <h1 className="text-2xl font-poppins font-bold text-white mt-6 mb-3">
              Votre inscription est presque terminée !
            </h1>
            
            <p className="text-slate-300 mb-8">
              Nous vous avons envoyé un email de confirmation. Veuillez vérifier votre boîte de réception et cliquer sur le lien pour valider votre compte.
            </p>

            <div className="bg-slate-800/50 p-4 rounded-lg flex items-center justify-center space-x-3">
              <Mail className="w-6 h-6 text-slate-400" />
              <p className="text-slate-400">Pensez à vérifier votre dossier spam.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default RegistrationSuccessPage;