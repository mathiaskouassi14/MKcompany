import React from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import ClientsList from '@/components/dashboard/ClientsList';

const AdminClientsPage = () => {
  return (
    <>
      <Helmet>
        <title>Gestion des Clients - MK COMPANY</title>
        <meta name="description" content="Gérez tous les clients de MK COMPANY." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Gestion des Clients
            </h1>
            <p className="text-slate-400">
              Consultez et gérez les informations de tous vos clients.
            </p>
          </div>
          <ClientsList />
        </div>
      </DashboardLayout>
    </>
  );
};

export default AdminClientsPage;
