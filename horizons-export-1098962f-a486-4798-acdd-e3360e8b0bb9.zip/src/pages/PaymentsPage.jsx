import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const PaymentsPage = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const fetchPayments = async () => {
      if (!user) return;
      setLoading(true);
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('client_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de charger les paiements.' });
      } else {
        setPayments(data);
      }
      setLoading(false);
    };

    fetchPayments();
  }, [user, toast]);

  const getStatusChip = (status) => {
    if (status === 'paid') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
          <CheckCircle className="w-3 h-3 mr-1.5" />
          Payé
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-500/10 text-yellow-400">
        <Clock className="w-3 h-3 mr-1.5" />
        En attente
      </span>
    );
  };

  return (
    <>
      <Helmet>
        <title>Mes Paiements - MK COMPANY</title>
        <meta name="description" content="Consultez votre historique de paiements." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Historique des Paiements
            </h1>
            <p className="text-slate-400">
              Suivez toutes vos transactions et téléchargez vos factures.
            </p>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect rounded-xl"
          >
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-700">
                <thead className="bg-slate-800/50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Montant</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Statut</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Date</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {loading ? (
                    <tr>
                      <td colSpan="4" className="text-center py-10">
                        <div className="flex justify-center items-center">
                          <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
                        </div>
                      </td>
                    </tr>
                  ) : payments.length === 0 ? (
                    <tr>
                      <td colSpan="4" className="text-center py-10 text-slate-400">
                        Aucun paiement trouvé.
                      </td>
                    </tr>
                  ) : (
                    payments.map((payment) => (
                      <tr key={payment.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">${payment.amount}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{getStatusChip(payment.status)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">{new Date(payment.payment_date).toLocaleDateString()}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button variant="link" className="text-emerald-400 hover:text-emerald-300 p-0 h-auto" onClick={() => toast({ title: '🚧 Bientôt disponible', description: 'Le téléchargement des factures sera bientôt disponible.' })}>Télécharger la facture</Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </DashboardLayout>
    </>
  );
};

export default PaymentsPage;