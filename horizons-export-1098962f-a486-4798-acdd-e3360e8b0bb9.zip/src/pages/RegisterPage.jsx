import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import RegisterForm from '@/components/auth/RegisterForm';

const RegisterPage = () => {
  return (
    <>
      <Helmet>
        <title>Inscription - MK COMPANY</title>
        <meta name="description" content="Créez votre compte MK COMPANY et commencez la création de votre LLC américaine dès aujourd'hui." />
      </Helmet>
      <div className="min-h-screen bg-slate-900 py-12 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto"
        >
          <div className="glass-effect rounded-2xl p-8 shadow-2xl">
            <div className="text-center mb-8">
              <Link to="/" className="inline-block mb-6">
                <img 
                  src="https://i.ibb.co/KjbYWZCv/Gemini-Generated-Image-as4dw1as4dw1as4d-removebg-preview.png" 
                  alt="MK COMPANY Logo" 
                  className="h-12 w-auto mx-auto"
                />
              </Link>
              <h1 className="text-2xl font-poppins font-bold text-white mb-2">
                Créer votre compte
              </h1>
              <p className="text-slate-400">
                Commencez votre création de LLC américaine
              </p>
            </div>
            
            <RegisterForm />
            
            <div className="mt-6 text-center">
              <p className="text-slate-400">
                Déjà un compte ?{' '}
                <Link 
                  to="/login" 
                  className="text-emerald-400 hover:text-emerald-300 font-medium transition-colors"
                >
                  Se connecter
                </Link>
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default RegisterPage;