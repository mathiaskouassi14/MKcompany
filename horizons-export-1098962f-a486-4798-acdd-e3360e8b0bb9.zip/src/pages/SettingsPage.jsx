import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, User, Phone, Calendar, Lock } from 'lucide-react';

const SettingsPage = () => {
  const { user, updateUser, updateUserPassword } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    dateOfBirth: '',
    email: '',
  });

  const [passwordData, setPasswordData] = useState({
    newPassword: '',
    confirmPassword: '',
  });

  useEffect(() => {
    if (user) {
      setFormData({
        firstName: user.user_metadata?.first_name || '',
        lastName: user.user_metadata?.last_name || '',
        phone: user.user_metadata?.phone || '',
        dateOfBirth: user.user_metadata?.date_of_birth || '',
        email: user.email || '',
      });
      setLoading(false);
    }
  }, [user]);

  const handleInfoChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = (e) => {
    setPasswordData({ ...passwordData, [e.target.name]: e.target.value });
  };

  const handleInfoSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    
    const { error } = await updateUser({
      data: { 
        first_name: formData.firstName,
        last_name: formData.lastName,
        phone: formData.phone,
        date_of_birth: formData.dateOfBirth,
      }
    });

    setIsSaving(false);

    if (error) {
      toast({
        variant: "destructive",
        title: "❌ Impossible de mettre à jour",
        description: "Une erreur est survenue. Veuillez réessayer.",
      });
    } else {
      toast({
        title: "✅ Succès",
        description: "Vos informations ont été mises à jour avec succès.",
        className: "bg-emerald-500/10 border-emerald-500/20 text-white"
      });
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "❌ Erreur",
        description: "Les nouveaux mots de passe ne correspondent pas.",
      });
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast({
        variant: "destructive",
        title: "❌ Erreur",
        description: "Le mot de passe doit contenir au moins 6 caractères.",
      });
      return;
    }

    setIsSavingPassword(true);

    const { error } = await updateUserPassword(passwordData.newPassword);
    
    setIsSavingPassword(false);

    if (error) {
       toast({
        variant: "destructive",
        title: "❌ Erreur de mise à jour",
        description: "Impossible de changer le mot de passe. Veuillez réessayer.",
      });
    } else {
      setPasswordData({ newPassword: '', confirmPassword: '' });
      toast({
        title: "✅ Succès",
        description: "Votre mot de passe a été mis à jour.",
        className: "bg-emerald-500/10 border-emerald-500/20 text-white"
      });
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <>
      <Helmet>
        <title>Paramètres - MK COMPANY</title>
        <meta name="description" content="Gérez vos informations personnelles et de sécurité." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-8">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Paramètres
            </h1>
            <p className="text-slate-400">
              Gérez vos informations personnelles et de sécurité.
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect rounded-xl p-6 lg:p-8"
          >
            <h2 className="text-xl font-poppins font-semibold text-white mb-6">Informations personnelles</h2>
            <form onSubmit={handleInfoSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="firstName" className="text-slate-300">Prénom</Label>
                  <div className="relative mt-1">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="firstName" name="firstName" value={formData.firstName} onChange={handleInfoChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="lastName" className="text-slate-300">Nom</Label>
                  <div className="relative mt-1">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="lastName" name="lastName" value={formData.lastName} onChange={handleInfoChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input id="email" name="email" type="email" value={formData.email} disabled className="mt-1 bg-slate-700/50 border-slate-600 text-slate-400 cursor-not-allowed" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="phone" className="text-slate-300">Téléphone</Label>
                  <div className="relative mt-1">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleInfoChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="dateOfBirth" className="text-slate-300">Date de naissance</Label>
                  <div className="relative mt-1">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="dateOfBirth" name="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={handleInfoChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button type="submit" disabled={isSaving}>
                  {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Enregistrer
                </Button>
              </div>
            </form>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="glass-effect rounded-xl p-6 lg:p-8"
          >
            <h2 className="text-xl font-poppins font-semibold text-white mb-6">Changer le mot de passe</h2>
            <form onSubmit={handlePasswordSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="newPassword">Nouveau mot de passe</Label>
                  <div className="relative mt-1">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="newPassword" name="newPassword" type="password" value={passwordData.newPassword} onChange={handlePasswordChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe</Label>
                  <div className="relative mt-1">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input id="confirmPassword" name="confirmPassword" type="password" value={passwordData.confirmPassword} onChange={handlePasswordChange} className="pl-10 bg-slate-800 border-slate-600 text-white" />
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button type="submit" disabled={isSavingPassword}>
                  {isSavingPassword && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Changer le mot de passe
                </Button>
              </div>
            </form>
          </motion.div>
        </div>
      </DashboardLayout>
    </>
  );
};

export default SettingsPage;