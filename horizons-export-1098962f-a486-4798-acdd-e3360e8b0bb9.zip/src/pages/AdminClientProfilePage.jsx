import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, User, Mail, Phone, Calendar, Briefcase, Building, MapPin, FileText, Upload, Bell, DollarSign, Download, ArrowLeft, ShieldCheck, ShieldX, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const AdminClientProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user: adminUser } = useAuth();

  const [client, setClient] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [identityDocuments, setIdentityDocuments] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  const [isUploading, setIsUploading] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadFileName, setUploadFileName] = useState('');

  const [isNotifying, setIsNotifying] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');

  const [isAddingPayment, setIsAddingPayment] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');

  const fetchClientData = useCallback(async () => {
    try {
      const { data: clientData, error: clientError } = await supabase
        .from('users')
        .select('*')
        .eq('id', id)
        .single();

      if (clientError) throw clientError;

      if (!clientData) {
        toast({ variant: 'destructive', title: 'Erreur', description: 'Client non trouvé.' });
        navigate('/admin/clients');
        return;
      }
      setClient(clientData);

      const { data: docData, error: docError } = await supabase.from('documents').select('*').eq('client_id', id).order('upload_date', { ascending: false });
      if (!docError) setDocuments(docData);

      const { data: idDocData, error: idDocError } = await supabase.from('identity_documents').select('*').eq('user_id', id).order('created_at', { ascending: false });
      if (!idDocError) setIdentityDocuments(idDocData);

      const { data: paymentData, error: paymentError } = await supabase.from('payments').select('*').eq('client_id', id).order('created_at', { ascending: false });
      if (!paymentError) setPayments(paymentData);

    } catch (error) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de charger les données du client.' });
      navigate('/admin/clients');
    } finally {
      setLoading(false);
    }
  }, [id, navigate, toast]);

  useEffect(() => {
    setLoading(true);
    fetchClientData();

    const channel = supabase.channel(`admin-client-profile-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'documents', filter: `client_id=eq.${id}` }, () => fetchClientData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'identity_documents', filter: `user_id=eq.${id}` }, () => fetchClientData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments', filter: `client_id=eq.${id}` }, () => fetchClientData())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, fetchClientData]);

  const handleFileUpload = async () => {
    if (!uploadFile || !uploadFileName) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Veuillez sélectionner un fichier et entrer un nom.' });
      return;
    }
    if (!adminUser) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Administrateur non authentifié.' });
      return;
    }
    setIsUploading(true);
    const filePath = `${id}/${Date.now()}-${uploadFile.name}`;
    const { error: uploadError } = await supabase.storage.from('documents').upload(filePath, uploadFile);

    if (uploadError) {
      toast({ variant: 'destructive', title: 'Erreur d\'upload', description: uploadError.message });
      setIsUploading(false);
      return;
    }

    const { error: dbError } = await supabase.from('documents').insert({
      client_id: id,
      document_name: uploadFileName,
      document_path: filePath,
      document_type: uploadFile.type,
      file_size: uploadFile.size,
      status: 'available',
      uploaded_by: adminUser.id,
    });

    if (dbError) {
      toast({ variant: 'destructive', title: 'Erreur base de données', description: dbError.message });
    } else {
      toast({ title: 'Succès', description: 'Document uploadé avec succès.' });
      setUploadFile(null);
      setUploadFileName('');
    }
    setIsUploading(false);
  };

  const handleSendNotification = async () => {
    if (!notificationMessage) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Le message ne peut pas être vide.' });
      return;
    }
    setIsNotifying(true);
    const { error } = await supabase.from('notifications').insert({
      client_id: id,
      message: notificationMessage,
      status: 'unread',
      priority: 'normal',
    });

    if (error) {
      toast({ variant: 'destructive', title: 'Erreur', description: error.message });
    } else {
      toast({ title: 'Succès', description: 'Notification envoyée.' });
      setNotificationMessage('');
    }
    setIsNotifying(false);
  };

  const handleAddPayment = async () => {
    if (!paymentAmount || !paymentMethod) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Veuillez remplir tous les champs.' });
      return;
    }
    setIsAddingPayment(true);
    const { error } = await supabase.from('payments').insert({
      client_id: id,
      amount: parseFloat(paymentAmount),
      payment_method: paymentMethod,
      status: 'paid',
      payment_date: new Date().toISOString(),
    });

    if (error) {
      toast({ variant: 'destructive', title: 'Erreur', description: error.message });
    } else {
      toast({ title: 'Succès', description: 'Paiement ajouté.' });
      setPaymentAmount('');
      setPaymentMethod('');
    }
    setIsAddingPayment(false);
  };

  const handleDownload = async (doc, storageBucket) => {
    const { data, error } = await supabase.storage.from(storageBucket).download(doc.document_url || doc.document_path);
    if (error) {
      toast({ variant: 'destructive', title: 'Erreur de téléchargement', description: error.message });
      return;
    }
    const blob = new Blob([data], { type: doc.document_type });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = doc.document_name || 'identity-document';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleIdDocStatusChange = async (docId, newStatus) => {
    const { error } = await supabase
      .from('identity_documents')
      .update({ status: newStatus })
      .eq('id', docId);

    if (error) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Impossible de mettre à jour le statut.' });
    } else {
      toast({ title: 'Succès', description: 'Statut mis à jour.' });
    }
  };

  if (loading || !client) {
    return <DashboardLayout><div className="flex justify-center items-center h-full"><Loader2 className="w-12 h-12 text-emerald-400 animate-spin" /></div></DashboardLayout>;
  }

  return (
    <>
      <Helmet><title>Profil Client - {client.first_name} {client.last_name}</title></Helmet>
      <DashboardLayout>
        <div className="space-y-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/clients')}>
              <ArrowLeft className="w-6 h-6 text-slate-300" />
            </Button>
            <div>
              <h1 className="text-3xl font-poppins font-bold text-white">{client.first_name} {client.last_name}</h1>
              <p className="text-slate-400">Inscrit le: {new Date(client.created_at).toLocaleDateString()}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <InfoCard icon={User} title="Nom complet" value={`${client.first_name} ${client.last_name}`} />
            <InfoCard icon={Mail} title="Email" value={client.email} />
            <InfoCard icon={Phone} title="Téléphone" value={client.phone || 'N/A'} />
            <InfoCard icon={Calendar} title="Date de naissance" value={client.date_of_birth ? new Date(client.date_of_birth).toLocaleDateString() : 'N/A'} />
            <InfoCard icon={DollarSign} title="Plan" value={client.plan || 'N/A'} />
            <InfoCard icon={Building} title="Nom LLC" value={client.llc_name || 'N/A'} />
            <InfoCard icon={MapPin} title="État de formation" value={client.formation_state || 'N/A'} />
            <InfoCard icon={Briefcase} title="Type de business" value={client.business_type || 'N/A'} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ActionCard title="Uploader un document" icon={Upload}>
              <div className="space-y-4">
                <Input placeholder="Nom du document" value={uploadFileName} onChange={(e) => setUploadFileName(e.target.value)} className="bg-slate-800 border-slate-600" />
                <Input type="file" onChange={(e) => setUploadFile(e.target.files[0])} className="bg-slate-800 border-slate-600 file:text-white" />
                <Button onClick={handleFileUpload} disabled={isUploading} className="w-full">
                  {isUploading ? <Loader2 className="animate-spin" /> : 'Uploader'}
                </Button>
              </div>
            </ActionCard>

            <ActionCard title="Envoyer une notification" icon={Bell}>
              <div className="space-y-4">
                <Input placeholder="Votre message..." value={notificationMessage} onChange={(e) => setNotificationMessage(e.target.value)} className="bg-slate-800 border-slate-600" />
                <Button onClick={handleSendNotification} disabled={isNotifying} className="w-full">
                  {isNotifying ? <Loader2 className="animate-spin" /> : 'Envoyer'}
                </Button>
              </div>
            </ActionCard>

            <ActionCard title="Ajouter un paiement" icon={DollarSign}>
              <div className="space-y-4">
                <Input type="number" placeholder="Montant" value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} className="bg-slate-800 border-slate-600" />
                <Input placeholder="Méthode (ex: Stripe)" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} className="bg-slate-800 border-slate-600" />
                <Button onClick={handleAddPayment} disabled={isAddingPayment} className="w-full">
                  {isAddingPayment ? <Loader2 className="animate-spin" /> : 'Ajouter'}
                </Button>
              </div>
            </ActionCard>
          </div>

          <ListCard title="Pièces d'identité du client" data={identityDocuments} renderItem={(doc) => (
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <IdStatusIcon status={doc.status} />
                <span>Pièce d'identité</span>
              </div>
              <div className="flex items-center gap-2">
                <Select onValueChange={(value) => handleIdDocStatusChange(doc.id, value)} defaultValue={doc.status}>
                  <SelectTrigger className="w-[140px] bg-slate-700 border-slate-600 text-sm h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="En attente">En attente</SelectItem>
                    <SelectItem value="Validé">Validé</SelectItem>
                    <SelectItem value="Rejeté">Rejeté</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="ghost" size="sm" onClick={() => handleDownload(doc, 'identity-documents')}><Download className="w-4 h-4" /></Button>
              </div>
            </div>
          )} />

          <ListCard title="Documents (Admin)" data={documents} renderItem={(doc) => (
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>{doc.document_name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-400">{new Date(doc.upload_date).toLocaleDateString()}</span>
                <Button variant="ghost" size="sm" onClick={() => handleDownload(doc, 'documents')}><Download className="w-4 h-4" /></Button>
              </div>
            </div>
          )} />

          <ListCard title="Historique des paiements" data={payments} renderItem={(payment) => (
            <div className="flex justify-between items-center">
              <span>${payment.amount} - {payment.payment_method}</span>
              <span className={`text-sm ${payment.status === 'paid' ? 'text-emerald-400' : 'text-yellow-400'}`}>{payment.status}</span>
            </div>
          )} />
        </div>
      </DashboardLayout>
    </>
  );
};

const InfoCard = ({ icon: Icon, title, value }) => (
  <div className="glass-effect p-4 rounded-lg">
    <div className="flex items-center gap-4">
      <Icon className="w-6 h-6 text-emerald-400" />
      <div>
        <p className="text-sm text-slate-400">{title}</p>
        <p className="font-semibold text-white">{value}</p>
      </div>
    </div>
  </div>
);

const ActionCard = ({ icon: Icon, title, children }) => (
  <div className="glass-effect p-6 rounded-lg">
    <div className="flex items-center gap-3 mb-4">
      <Icon className="w-5 h-5 text-emerald-400" />
      <h3 className="text-lg font-semibold text-white">{title}</h3>
    </div>
    {children}
  </div>
);

const ListCard = ({ title, data, renderItem }) => (
  <div className="glass-effect p-6 rounded-lg">
    <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
    <div className="space-y-3">
      {data.length > 0 ? data.map((item) => (
        <div key={item.id} className="bg-slate-800/50 p-3 rounded">
          {renderItem(item)}
        </div>
      )) : <p className="text-slate-400">Aucune donnée.</p>}
    </div>
  </div>
);

const IdStatusIcon = ({ status }) => {
  if (status === 'Validé') return <ShieldCheck className="w-4 h-4 text-emerald-400" />;
  if (status === 'Rejeté') return <ShieldX className="w-4 h-4 text-red-400" />;
  return <ShieldAlert className="w-4 h-4 text-yellow-400" />;
};

export default AdminClientProfilePage;