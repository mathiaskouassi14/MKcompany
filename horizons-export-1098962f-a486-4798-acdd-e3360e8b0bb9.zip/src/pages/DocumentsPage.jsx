import React from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import RecentDocuments from '@/components/dashboard/RecentDocuments';

const DocumentsPage = () => {
  return (
    <>
      <Helmet>
        <title>Mes Documents - MK COMPANY</title>
        <meta name="description" content="Consultez et téléchargez vos documents importants." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Mes Documents
            </h1>
            <p className="text-slate-400">
              Retrouvez ici tous les documents relatifs à la création de votre LLC.
            </p>
          </div>
          
          <RecentDocuments showViewAll={false} />
        </div>
      </DashboardLayout>
    </>
  );
};

export default DocumentsPage;