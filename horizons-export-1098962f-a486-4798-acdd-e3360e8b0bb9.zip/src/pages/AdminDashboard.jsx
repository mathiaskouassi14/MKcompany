import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import AdminStats from '@/components/dashboard/AdminStats';
import ClientsList from '@/components/dashboard/ClientsList';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2 } from 'lucide-react';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    clients: 0,
    llcCreated: 0,
    revenue: 0,
    newClients: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      try {
        const { count: clientCount, error: countError } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .eq('role', 'client');

        if (countError) throw countError;

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const { count: newClientsCount, error: newClientsError } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .eq('role', 'client')
          .gt('created_at', thirtyDaysAgo.toISOString());

        if (newClientsError) throw newClientsError;

        const { data: payments, error: paymentsError } = await supabase
          .from('payments')
          .select('amount')
          .eq('status', 'paid');

        if (paymentsError) throw paymentsError;

        const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
        
        setStats({
          clients: clientCount,
          llcCreated: clientCount, // Assuming 1 LLC per client for now
          revenue: totalRevenue,
          newClients: newClientsCount,
        });

      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard Admin - MK COMPANY</title>
        <meta name="description" content="Interface d'administration MK COMPANY pour gérer les créations de LLC américaines." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Administration
            </h1>
            <p className="text-slate-400">
              Gérez vos clients et leurs demandes de LLC
            </p>
          </div>
          
          <AdminStats stats={stats} />
          
          <ClientsList limit={5} />
        </div>
      </DashboardLayout>
    </>
  );
};

export default AdminDashboard;