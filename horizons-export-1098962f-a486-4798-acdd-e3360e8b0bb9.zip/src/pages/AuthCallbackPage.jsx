import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

// Helper to convert Data URL to Blob
const dataURLtoBlob = (dataurl) => {
  const arr = dataurl.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
};

const AuthCallbackPage = () => {
  const navigate = useNavigate();
  const { session, user, updateUser } = useAuth();
  const [status, setStatus] = useState('validating'); // validating, uploading, success, error

  useEffect(() => {
    const completeRegistration = async () => {
      if (session && user) {
        const pendingRegRaw = localStorage.getItem('pendingRegistration');
        const pendingFileRaw = localStorage.getItem('pendingFile');

        if (pendingRegRaw && pendingFileRaw) {
          setStatus('uploading');
          const pendingReg = JSON.parse(pendingRegRaw);
          
          if (pendingReg.email === user.email) {
            const fileBlob = dataURLtoBlob(pendingFileRaw);
            const filePath = `public/${user.id}/${pendingReg.idDocumentName}`;

            const { error: uploadError } = await supabase.storage
              .from('documents')
              .upload(filePath, fileBlob, {
                upsert: true, // Overwrite if it exists, useful for retries
              });

            if (uploadError) {
              console.error("Upload error:", uploadError);
              setStatus('error');
              // Clean up local storage even on error
              localStorage.removeItem('pendingRegistration');
              localStorage.removeItem('pendingFile');
              return;
            }

            const { error: updateUserError } = await updateUser({
              data: { id_document_path: filePath }
            });

            if (updateUserError) {
              console.error("Update user error:", updateUserError);
              setStatus('error');
              // Clean up local storage even on error
              localStorage.removeItem('pendingRegistration');
              localStorage.removeItem('pendingFile');
              return;
            }

            // Success! Clean up and redirect.
            localStorage.removeItem('pendingRegistration');
            localStorage.removeItem('pendingFile');
            setStatus('success');
          }
        } else {
          // Regular login, just set status to success
          setStatus('success');
        }
      }
    };

    completeRegistration();
  }, [session, user, updateUser]);

  useEffect(() => {
    if (status === 'success') {
      const redirectTimeout = setTimeout(() => {
        const userRole = session?.user?.user_metadata?.role;
        if (userRole === 'admin') {
          navigate('/admin/dashboard');
        } else {
          navigate('/client/dashboard');
        }
      }, 1500);

      return () => clearTimeout(redirectTimeout);
    }
  }, [status, session, navigate]);

  const statusContent = {
    validating: {
      icon: <Loader2 className="w-16 h-16 text-emerald-400 animate-spin mx-auto" />,
      title: "Validation de votre compte...",
      message: "Veuillez patienter, nous vérifions votre session.",
    },
    uploading: {
      icon: <Loader2 className="w-16 h-16 text-emerald-400 animate-spin mx-auto" />,
      title: "Finalisation de l'inscription...",
      message: "Téléchargement sécurisé de vos documents en cours.",
    },
    success: {
      icon: <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto" />,
      title: "Validation réussie !",
      message: "Vous allez être redirigé vers votre tableau de bord.",
    },
    error: {
      icon: <AlertTriangle className="w-16 h-16 text-red-500 mx-auto" />,
      title: "Une erreur est survenue",
      message: "Impossible de finaliser votre inscription. Veuillez contacter le support.",
    },
  };

  const currentStatus = statusContent[status];

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        {currentStatus.icon}
        <h1 className="text-2xl font-poppins font-bold mt-6">
          {currentStatus.title}
        </h1>
        <p className="text-slate-400 mt-2">
          {currentStatus.message}
        </p>
      </motion.div>
    </div>
  );
};

export default AuthCallbackPage;