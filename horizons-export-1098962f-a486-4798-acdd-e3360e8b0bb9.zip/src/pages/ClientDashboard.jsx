import React from 'react';
import { Helmet } from 'react-helmet';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import DashboardStats from '@/components/dashboard/DashboardStats';
import RecentDocuments from '@/components/dashboard/RecentDocuments';
import StatusWidget from '@/components/dashboard/StatusWidget';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Loader2 } from 'lucide-react';

const ClientDashboard = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  const welcomeName = user?.user_metadata?.first_name || 'Client';

  return (
    <>
      <Helmet>
        <title>Dashboard Client - MK COMPANY</title>
        <meta name="description" content="Suivez l'avancement de votre création de LLC américaine sur votre dashboard client MK COMPANY." />
      </Helmet>
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-poppins font-bold text-white mb-2">
              Tableau de bord
            </h1>
            <p className="text-slate-400">
              Bienvenue, {welcomeName} ! Heureux de vous revoir.
            </p>
          </div>
          
          <DashboardStats />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <RecentDocuments limit={3} showViewAll={true} />
            </div>
            <div className="space-y-6">
              <StatusWidget />
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  );
};

export default ClientDashboard;