import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

const dataURLtoBlob = (dataurl) => {
  const arr = dataurl.split(',');
  const mimeMatch = arr[0].match(/:(.*?);/);
  if (!mimeMatch) return null;
  const mime = mimeMatch[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
};

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const handlePostSignUp = useCallback(async (user) => {
    const pendingFileStr = localStorage.getItem('pendingFile');
    if (!pendingFileStr) return;

    try {
      // Check if the string is a JSON string
      let pendingFile;
      if (pendingFileStr.startsWith('{')) {
        pendingFile = JSON.parse(pendingFileStr);
      } else {
        // It's not a JSON, so it's an old format or an error.
        // We can try to handle it or just remove it to prevent loops.
        console.warn("pendingFile in localStorage was not a valid JSON. Clearing it.");
        localStorage.removeItem('pendingFile');
        return;
      }
      
      const fileBlob = dataURLtoBlob(pendingFile.dataUrl);
      if (!fileBlob) throw new Error("Invalid file data URL");
      
      const filePath = `${user.id}/${Date.now()}-${pendingFile.name}`;

      const { error: uploadError } = await supabase.storage
        .from('identity-documents')
        .upload(filePath, fileBlob);

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase
        .from('identity_documents')
        .insert({
          user_id: user.id,
          document_type: pendingFile.type,
          document_url: filePath,
          status: 'En attente',
        });

      if (dbError) throw dbError;

      localStorage.removeItem('pendingFile');
      toast({
        title: "Document soumis",
        description: "Votre pièce d'identité a été soumise pour validation.",
      });
    } catch (error) {
      console.error("Post-sign-up error:", error);
      toast({
        variant: "destructive",
        title: "Erreur post-inscription",
        description: "Impossible de traiter votre document. Veuillez réessayer depuis votre dashboard.",
      });
      // Clear the item to prevent error loops
      localStorage.removeItem('pendingFile');
    }
  }, [toast]);

  const handleSession = useCallback(async (session) => {
    setSession(session);
    const currentUser = session?.user ?? null;
    setUser(currentUser);
    setLoading(false);

    if (currentUser && localStorage.getItem('pendingFile')) {
      await handlePostSignUp(currentUser);
    }
  }, [handlePostSignUp]);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      handleSession(session);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        handleSession(session);
      }
    );

    return () => subscription.unsubscribe();
  }, [handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options,
    });

    return { data, error };
  }, []);

  const signIn = useCallback(async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: error.message || "Something went wrong",
      });
    }

    return { error };
  }, [toast]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign out Failed",
        description: error.message || "Something went wrong",
      });
    }

    return { error };
  }, [toast]);

  const updateUser = useCallback(async (attributes) => {
    const { data, error } = await supabase.auth.updateUser(attributes);
    return { data, error };
  }, []);

  const updateUserPassword = useCallback(async (newPassword) => {
    const { data, error } = await supabase.auth.updateUser({ password: newPassword });
    return { data, error };
  }, []);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    updateUser,
    updateUserPassword,
  }), [user, session, loading, signUp, signIn, signOut, updateUser, updateUserPassword]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};